package com.example.shifood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class InterfazUsuarioPrem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz_usuario_prem);
    }
    public void recetas(View view) {
        Intent intent = new Intent(this, Recetas1.class);
        startActivity(intent);
    }

    public void chefsito(View view) {
        Intent intent = new Intent(this, InterfazChef.class);
        startActivity(intent);
    }
    public void interfplan(View view){
        Intent intent = new Intent(this, InterfazPlan.class);
        startActivity(intent);
    }
}