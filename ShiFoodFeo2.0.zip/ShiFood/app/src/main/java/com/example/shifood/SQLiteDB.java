package com.example.shifood;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDB extends SQLiteOpenHelper {
    public SQLiteDB(Context context) {
        super(context, "dbUsuarios", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table Usuario (nombre varchar(50), password varchar(50), password2 varchar(50), correo varchar(50))";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertarDatos(String nom, String pass, String pass2, String correo1){
        SQLiteDatabase database = getWritableDatabase();
        String sql = String.format("insert into Deudas (nombre,password,password2,correo) values ('%s', '%s', '%s', '%s')", nom, pass,pass2,correo1);
        database.execSQL(sql);
        database.close();
    }

    }

