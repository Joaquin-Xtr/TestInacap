package com.example.shifood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class InterfazUsuario1 extends AppCompatActivity {
    private Button btnlink;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz_usuario1);

        btnlink = findViewById(R.id.btnLink);
        url="https://forms.gle/muWXd4RCLUiah6LC9";

        btnlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }

    public void recetas(View view) {
        Intent intent = new Intent(this, Recetas1.class);
        startActivity(intent);
    }

    public void chefsito(View view) {
        Intent intent = new Intent(this, InterfazChef.class);
        startActivity(intent);
    }
    public void interfplan(View view){
        Intent intent = new Intent(this, PremiumUsuario.class);
        startActivity(intent);
    }
}